from pyteal.compiler.optimizer.optimizer import (
    OptimizeOptions,
    apply_global_optimizations,
)
